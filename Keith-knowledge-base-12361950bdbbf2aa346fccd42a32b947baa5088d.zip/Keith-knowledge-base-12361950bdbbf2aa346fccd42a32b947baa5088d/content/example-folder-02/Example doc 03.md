---
title: A third example doc inside a folder
---
This is an example doc. Docs are Markdown files inside the `content/` directory.

---

Return to the [[index]]